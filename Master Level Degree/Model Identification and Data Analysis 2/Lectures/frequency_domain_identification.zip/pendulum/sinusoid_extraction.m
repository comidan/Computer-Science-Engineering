function [B_hat, phi_hat] = sinusoid_extraction(y,t,omega)


% [a_hat]   [ sum(sin(omega*t).^2)  sum(sin(omega*t).*cos(omega*t))]^-1 [sum(y.*sin(omega*t))]
%         = [                                                      ]    [                    ]
% [b_hat]   [ sum(sin(omega*t).*cos(omega*t))  sum(cos(omega*t).^2)]    [sum(y.*cos(omega*t))]
%

A = [sum(sin(omega*t).^2)               sum(sin(omega*t).*cos(omega*t)); 
     sum(sin(omega*t).*cos(omega*t))    sum(cos(omega*t).^2)];

b = [sum(y.*sin(omega*t));
     sum(y.*cos(omega*t));];

x = A\b;

a_hat = x(1);
b_hat = x(2);

phi_hat = atan2(b_hat, a_hat);
B_hat = (a_hat/cos(phi_hat) + b_hat/sin(phi_hat))/2;


end

