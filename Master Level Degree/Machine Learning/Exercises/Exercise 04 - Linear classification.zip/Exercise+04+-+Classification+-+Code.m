clear
clc
close all

%% Initialization
load iris_dataset.mat;
x = zscore(irisInputs([1 2],:)');
t = irisTargets(1,:)';
gplotmatrix(x,[],t);

%% Naive bayes
nb_model = fitcnb(x, t);

t_pred = predict(nb_model, x);
conf_mat = confusionmat(t, t_pred);
confusionchart(conf_mat)
title('NB confusion Matrix (MATLAB)');

figure();
gscatter(x(:,1), x(:,2), t);
hold on;
axis manual

[a, b] = meshgrid(-3:0.1:3, -3:0.1:4);
axis tight;
pred = predict(nb_model,[a(:), b(:)]);
gscatter(a(:), b(:), pred);
title('NB classifier');

%% NB by hand
n_classes = length(unique(t));
[n_samples, n_features] = size(x);

for ii = 1:n_classes
    prior(ii) = sum(t == (ii - 1)) / n_samples;
    feature_mean(ii, :) = mean(x(t == (ii-1), :));
    feature_std(ii, :) = std(x(t == (ii-1), :));
end

for ii = 1:n_classes
    MAP(:, ii) = prior(ii) * ones(n_samples, 1);
    for jj = 1:n_features
        MAP(:, ii) = MAP(:, ii) .* normpdf(x(:,jj), feature_mean(ii, jj), feature_std(ii, jj));
    end
end

[~, t_pred_by_hand] = max(MAP, [], 2);
conf_mat = confusionmat(t, t_pred_by_hand-1);
figure();
confusionchart(conf_mat);
title('NB confusion Matrix (By hand)');

%% Generative abilities of NB
param = nb_model.DistributionParameters;
prior = cumsum(nb_model.Prior);
n_dim = size(param, 2);

n_gen = 1000;
gendata = zeros(n_gen,n_dim);
gentarget = zeros(n_gen,1);

for ii = 1:n_gen
    gentarget(ii) = find(prior > rand(),1);
    for jj = 1:n_dim
        mu = param{gentarget(ii),jj}(1);
        sigma = param{gentarget(ii),jj}(2);
        gendata(ii,jj) = normrnd(mu,sigma);
    end
end

figure();
gscatter(gendata(:,1), gendata(:,2), gentarget);
title('NB generated data');
%% KNN classifier
k = 1;
knn_model = fitcknn(x, t, 'NumNeighbors', k);
t_pred = predict(knn_model,x);
confusionmat(t, t_pred)

figure();
gscatter(x(:,1),x(:,2),t);
hold on;
axis manual

[a, b] = meshgrid(-3:0.1:3,-3:0.1:4);
axis tight
pred = predict(knn_model,[a(:),b(:)]);
gscatter(a(:), b(:), pred);
title(['K-NN classifier, k = ' num2str(k)]);


%% NB for multiple classes
[t, ~] = find(irisTargets ~= 0);
nb_model = fitcnb(x, t);

t_pred = predict(nb_model, x);
conf_mat = confusionmat(t, t_pred);
figure();
confusionchart(conf_mat)
title('NB confusion Matrix (MATLAB)');

figure();
gscatter(x(:,1), x(:,2), t);
hold on;
axis manual

[a, b] = meshgrid(-3:0.1:3, -3:0.1:4);
axis tight;
pred = predict(nb_model,[a(:), b(:)]);
gscatter(a(:), b(:), pred);
title('NB classifier');
