function J = cost_function(theta, sample_freq_resp, omega_vect)

Ts = 0.001;

% transfer function parameters
b1 = theta(1)*1e-6; 
a1 = theta(2);
a2 = theta(3);

% transfer function parametric model
W = @(x) (b1)/(x^2+a1*x+a2);

% transfer function evaluation
W_sample = arrayfun(W, exp(1i*omega_vect*Ts));

% error computation
error = W_sample - sample_freq_resp; % it is a complex number

error_re = real(error);
error_im = imag(error);

J = (sum(error_re.^2) + sum(error_im.^2))*1e6;


