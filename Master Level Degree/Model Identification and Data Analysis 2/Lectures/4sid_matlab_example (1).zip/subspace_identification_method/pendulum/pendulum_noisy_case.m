clear
close all
clc

%% pendulum Torque2Position transfer function estimation - noisy case

%% system parameters 

m    = 1;         % [kg]      mass
l    = 0.5;       % [m]       rod length
g    = 9.81;      % [m/s^2]   gravitational acceleration 
c    = 1;         % [N*m*s]   damping coefficient
Ts   = 0.01;      % [s]       sampling time (100 Hz)
N    = 400;       % []        number of measurement
Tf   = Ts*(N-1);  % [s]       simulation duration
time = 0:Ts:Tf;   % [s]       time vector

noise_free = false;           % true = mesurements without noise - false = measurements with noise

%% impulse input definition 

% figure
fig_IR = figure('Name','IR');
ax_IR_y = subplot(2,1,1); 
hold all, grid on, box on;
set(gca,'FontSize',15,'DefaultLineLineWidth',2);
xlabel('time [s]');
ylabel('position [deg]');
ax_IR_u = subplot(2,1,2);
hold all, grid on, box on;
set(gca,'FontSize',15,'DefaultLineLineWidth',2);
xlabel('time [s]');
ylabel('\tau [Nm]');
ax = [ax_IR_u ax_IR_y];

u_impulse     = zeros(1,N);
u_impulse(1)  = 50;                                       
u_sim         = timeseries(u_impulse,time); % the "from workspace" block in simulink need a timeseries object

plot(ax_IR_u,time,u_impulse,'o');

% note that the impulse is not unitary! When you extract the matrix G you
% have to divide it by u(1)

%% simulation
sim('pendulum_sim');
omega = y_sim;                                                 % [rad] y_sim is saved from the simulink scheme ("to workspace" block) 
plot(ax_IR_y,time,omega*180/pi,'o');
linkaxes(ax,'x'); clear ax;                                             % save simulation output variable

                                                      % graphical cmd (linkaxes)

%% Henkel matrix computation and rank analysis (noise free method)

H1 = [omega(2)];

H2 = [omega(2) omega(3);
      omega(3) omega(4)];

H3 = [omega(2) omega(3) omega(4);
      omega(3) omega(4) omega(5);
      omega(4) omega(5) omega(6)];
   
H4 = [omega(2) omega(3) omega(4) omega(5);
      omega(3) omega(4) omega(5) omega(6);
      omega(4) omega(5) omega(6) omega(7);
      omega(5) omega(6) omega(7) omega(8)];
  
rH1 = rank(H1);
rH2 = rank(H2);
rH3 = rank(H3);
rH4 = rank(H4);

disp(['The rank of H1 is: ' num2str(rH1)]);
disp(['The rank of H2 is: ' num2str(rH2)]);
disp(['The rank of H3 is: ' num2str(rH3)]);
disp(['The rank of H4 is: ' num2str(rH4)]);

%% hankel matrix construction 

% q and d are design parameters. Rules: 
% q ~ d better accuracy
% q << d lower computational complexity 

q = 190; 
d = 210;

hankel_matrix_qd = nan(q,d); % predefinition of Henkel matrix

% Henkel matrix creation 
for i_row = 1:q
   hankel_matrix_qd(i_row,:) = omega(i_row+1:d+i_row); 
end


%% singular values analysis
[U,S,V] = svd(hankel_matrix_qd);    % singular values decomposition
V_tr    = V';                       % V matrix transpose
sv      = diag(S);                  % singular values extraction

% plot of singular values
fig_singular_values = figure('Name','singular_values');
hold all, grid on, box on;
set(gca,'FontSize',15);
ylabel('singular vaues (normalized)');
stem(sv/max(sv),'LineWidth',2);


%% system order choice
n = 2;                  % clear jump between second and third singular values

%% general 4sid method
% We use the method you have seen during lecture

U_hat    = U(:,1:n);
S_hat    = S(1:n,1:n);
V_hat_tr = V_tr(1:n,:);

O_hat = U_hat*sqrtm(S_hat);
R_hat = sqrtm(S_hat)*V_hat_tr;

H_hat = O_hat(1,:);
G_hat = R_hat(:,1)/u_impulse(1);     

O_hat1 = O_hat(1:q-1,:);
O_hat2 = O_hat(2:q,:);

F_hat = pinv(O_hat1)*O_hat2;        % Ohat_1 is a rectangular matrix, we have to compute the pseudo-inverse 
D_hat = 0;

% estimated transfer function computation
sys   = ss(F_hat,G_hat,H_hat,D_hat,Ts);
W_hat = tf(sys);

%% validation

% step input definition
step_time      = 1;
step_amplitude = 2;

u_validation        = step_amplitude*(time >= step_time);                   % step input definition
u_sim               = timeseries(u_validation,time);                        % simulation input definition
sim('pendulum_sim');
y_validation        = y_sim;
y_validation_hat    = lsim(W_hat,u_validation,time);                        % lsim simulate a linear system described by a transfer function


% plot validation 
fig_validation = figure('Name','validation');
subplot(2,1,1)
hold all, grid on, box on;
set(gca,'DefaultLineLineWidth', 2,...
    'FontSize',15);
xlabel('time [s]');                                                         % graphical cmd
ylabel('position [deg]');
plot(time,y_validation*180/pi,'o')
plot(time,y_validation_hat*180/pi,'o');
legend('measured','estimated');

subplot(2,1,2)
hold all, grid on, box on;
set(gca,'DefaultLineLineWidth', 2,...
    'FontSize',15);
xlabel('time [s]');                                                         
ylabel('\tau [Nm]');
plot(time,u_validation,'o')
