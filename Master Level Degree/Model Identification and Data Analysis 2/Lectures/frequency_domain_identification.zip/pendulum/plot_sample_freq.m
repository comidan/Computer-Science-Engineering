clear
close all
clc


load .\data\sample_freq_resp.mat

figure
ax_freq(1) = subplot(2,1,1); hold all, grid on, box on; ylabel('mag [dB]'); xlabel('f [Hz]'); set(gca, 'XScale','Log');
scatter(f_vect, mag2db(abs(sample_freq_resp)));
ax_freq(2) = subplot(2,1,2); hold all, grid on, box on; ylabel('ph [deg]'); xlabel('f [Hz]'); set(gca, 'XScale','Log');
scatter(f_vect, angle(sample_freq_resp)*180/pi);