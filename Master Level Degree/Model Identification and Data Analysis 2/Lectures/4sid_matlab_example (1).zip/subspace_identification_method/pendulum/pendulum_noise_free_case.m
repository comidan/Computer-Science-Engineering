clear
close all
clc

%% pendulum Torque2Position transfer function estimation - noise free

%% system parameters 
m    = 1;         % [kg]        mass
l    = 0.5;       % [m]         rod length
g    = 9.81;      % [m/s^2]     gravity acceleration
c    = 1;         % [N*s/m]     damping coefficient
Ts   = 0.01;      % [s]         sampling time (100Hz)
N    = 400;       % [ ]         number of measurements
Tf   = Ts*(N-1);  % [s]         simulation Horizon
time = 0:Ts:Tf;   % [s]         time vector

noise_free = false;  % true = mesurements without noise - false = measurements with noise

%% impulse input definition 

% figure
fig_IR = figure('Name','IR');
ax_IR_y = subplot(2,1,1); 
hold all, grid on, box on;
set(gca,'FontSize',15,'DefaultLineLineWidth',2);
xlabel('time [s]');
ylabel('position [deg]');
ax_IR_u = subplot(2,1,2);
hold all, grid on, box on;
set(gca,'FontSize',15,'DefaultLineLineWidth',2);
xlabel('time [s]');
ylabel('\tau [Nm]');
ax = [ax_IR_u ax_IR_y];

u_impulse     = zeros(1,N);
u_impulse(1)  = 50;                                       
u_sim         = timeseries(u_impulse,time); % the "from workspace" block in simulink need a timeseries object

plot(ax_IR_u,time,u_impulse,'o');

% note that the impulse is not unitary! When you extract the matrix G you
% have to divide it by u(1)

%% simulation
sim('pendulum_sim');
omega = y_sim;                                                 % [rad] y_sim is saved from the simulink scheme ("to workspace" block) 
plot(ax_IR_y,time,omega*180/pi,'o');
linkaxes(ax,'x'); clear ax;     

%% Henkel matrix computation
% note that the matlab vector indexing starts from 1 not from 0!!! 
% omega(0) = y(1); omega(1)=y(2); omega(2)=y(3) and so on

H1 = omega(2);

H2 = [omega(2) omega(3)
      omega(3) omega(4)];

H3 = [omega(2) omega(3) omega(4)
      omega(3) omega(4) omega(5)
      omega(4) omega(5) omega(6)];
  
rH1 = rank(H1);
rH2 = rank(H2);
rH3 = rank(H3);

disp(['The rank of H1 is: ' num2str(rH1)]);
disp(['The rank of H2 is: ' num2str(rH2)]);
disp(['The rank of H3 is: ' num2str(rH3)]);


%% choice of the order system
n = 2;

%% factorization of H3 H(n+1);
% we find the factorization using the same method seen in classroom

R3 = H3(1:2,:);         % put in R3 2 indipendent rows of H3 (for example the first 2 rows)

% we have to find the linear combination of the 2 indipendent rows in order
% to obtain the third one. 
A_x = H3(1:2,:)';     
b_x = H3(3,:)';
x = linsolve(A_x,b_x);

a = x(1);
b = x(2);

O3 = [ 1    0;
       0    1;
       a    b];

%% matrix extraction
H_hat = O3(1,:);                            % first row of O_n+1
G_hat = R3(:,1)./u_impulse(1);              % first column  of R_n+1, since the impulse input is not unitary, G must be divided by u(1)
F_hat = inv(O3(1:n,:))*O3(2:n+1,:);         % inverse of the first n rows of O_n+1 times the last n rows of O_n+1
D_hat = 0;                                  

% estimated transfer function computation
sys   = ss(F_hat,G_hat,H_hat,D_hat,Ts);
W_hat = tf(sys);

%% validation input

% validation figure
fig_validation = figure('Name','validation');
ax_validation_y = subplot(2,1,1);
hold all, grid on, box on;
set(gca,'DefaultLineLineWidth', 2,...
    'FontSize',15);
xlabel('time [s]');                                                         % graphical cmd
ylabel('position [deg]');
legend show

ax_validation_u = subplot(2,1,2);
hold all, grid on, box on;
set(gca,'DefaultLineLineWidth', 2,...
    'FontSize',15);
xlabel('time [s]');                                                         
ylabel('\tau [Nm]');


% step input definition
step_time = 1;
step_amplitude = 1;
u_validation = step_amplitude*(time >= step_time);            % step input definition
plot(time,u_validation,'o')

%% validation simulation
u_sim = timeseries(u_validation,time);                        % simulation input definition
sim('pendulum_sim');
y_validation = y_sim;
plot(ax_validation_y, time, y_validation*180/pi,'o','DisplayName','simulated')


%% validation comparison
y_validation_hat = lsim(W_hat,u_validation,time);                        % lsim simulate a linear system described by a transfer function
plot(ax_validation_y, time, y_validation_hat*180/pi,'o','DisplayName','Estimated');



