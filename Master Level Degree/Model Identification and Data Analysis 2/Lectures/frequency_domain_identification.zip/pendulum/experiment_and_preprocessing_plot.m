clear
close all
clc

m    = 1;         % [kg]      mass
l    = 0.5;       % [m]       rod length
g    = 9.81;      % [m/s^2]   gravitational acceleration
c    = 1;         % [N*m*s]   damping coefficient
Ts   = 0.001;     % [s]       sampling time (100 Hz)

noise_gain = 1;   %[ ] noise gain

%% estimation of frequency response

A = 20;

Tf = 240;

freq_min = 1;
freq_max = 5;

f_vect = logspace(log10(freq_min),log10(freq_max),3);

B_hat = nan(1,length(f_vect));
phi_hat = nan(1,length(f_vect));
sample_freq_resp = nan(1,length(f_vect));


figure
hold all, grid on, box on, ylabel('y [deg]'); xlabel('t [s]'); 

for i_f = 1:length(f_vect)
    t = 0:Ts:Tf; % time vector
    f = f_vect(i_f); % [Hz] frequency selection
    omega = 2*pi*f; % [rad/s]
    
    u = A*sin(omega*t); %input definition
    
    u_sim = timeseries(u, t); % timeseries for simulation
    
    sim('pendulum_sim'); % simulation
    
    y = y_sim.Data'; % data selection
    
    % neglection of first period 
    selector = t>=1/f;
    u = u(selector);
    y = y(selector);
    t = t(selector)-1/f; 
    
    h(i_f) = plot(t, y, 'o','displaynam',['f=' num2str(f) ' Hz']);

    [B_hat(i_f), phi_hat(i_f)] = sinusoid_extraction(y,t,omega);
    plot(t, B_hat(i_f)*sin(2*pi*f*t + phi_hat(i_f)),'g--');

    sample_freq_resp(i_f) = B_hat(i_f)/A*exp(1i*phi_hat(i_f));

end

xlim([10 12])

legend(h)



