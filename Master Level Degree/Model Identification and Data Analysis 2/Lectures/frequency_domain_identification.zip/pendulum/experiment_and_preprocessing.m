clear
close all
clc

m    = 1;         % [kg]      mass
l    = 0.5;       % [m]       rod length
g    = 9.81;      % [m/s^2]   gravitational acceleration
c    = 1;         % [N*m*s]   damping coefficient
Ts   = 0.001;     % [s]       sampling time (100 Hz)

noise_gain = 1;   %[ ] noise gain

%% estimation of frequency response
Tf = 240; % exeperiment duration

A = 20; % input amplitude 

% set of frequencies to be tested
freq_min = 0.1; %[Hz]
freq_max = 9; %[Hz]
f_vect = logspace(log10(freq_min),log10(freq_max),25);

B_hat = nan(1,length(f_vect));
phi_hat = nan(1,length(f_vect));
sample_freq_resp = nan(1,length(f_vect));

for i_f = 1:length(f_vect)
    
    % input definition
    t = 0:Ts:Tf;
    f = f_vect(i_f); %[Hz]
    omega = 2*pi*f; %[rad/s]
    u = A*sin(omega*t); %input
    u_sim = timeseries(u, t); % timeseries for simulation
    
    % system simulation
    sim('pendulum_sim');
    y = y_sim.Data'; % data extraction
    
    % data cutting 
    selector = t>=1/f;
    u = u(selector);
    y = y(selector);
    t = t(selector)-1/f; 
    
    % sample frequency response computation
    [B_hat(i_f), phi_hat(i_f)] = sinusoid_extraction(y,t,omega);
    sample_freq_resp(i_f) = B_hat(i_f)/A*exp(1i*phi_hat(i_f));
    
end

save('.\data\sample_freq_resp.mat','sample_freq_resp','f_vect');
