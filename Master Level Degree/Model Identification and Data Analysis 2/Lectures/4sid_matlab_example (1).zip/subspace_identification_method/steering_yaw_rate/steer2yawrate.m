clear
close all
clc

Ts = 0.01;                                                                   % [s] sampling time of the experiments
   
identification_experiment = load('./data/identification_experiment.mat');    % load data used for identification 

% data plot (yaw rate and steering wheel angle)
fig_experiment = figure('Name','experiment');
ax(1) = subplot(2,1,1);
hold all, grid on, box on;
set(gca,'DefaultLineLineWidth',2,...
    'FontSize',15);
plot(identification_experiment.time, identification_experiment.yaw_rate,'o')
xlabel('time [s]');
ylabel('yaw rate [deg/s]');

ax(end+1) = subplot(2,1,2);
hold all, grid on, box on;
set(gca,'DefaultLineLineWidth',2,...
    'FontSize',15);
plot(identification_experiment.time,identification_experiment.steering_wheel,'o')
xlabel('time [s]');
ylabel('steering wheel [deg]');

linkaxes(ax,'x'); clear ax;


%% choice of system order
n = 5;

%% identification 

y_id = identification_experiment.yaw_rate;
u_id = identification_experiment.steering_wheel;

data     = iddata(y_id,u_id,Ts);                             
n4sidopt = n4sidOptions('EnforceStability',true);     
sys      = n4sid(data,n,n4sidopt);            

% compute the transfer function for validation
F = sys.A;
G = sys.B;
H = sys.C;
D = sys.D;
W_hat  = tf(ss(F,G,H,D,Ts));

%% validation trajectory following (_tf)

validation_tf = load('./data/validation_experiment_tf.mat');

u_validation_tf     = validation_tf.steering_wheel;
y_validation_tf     = validation_tf.yaw_rate;
y_validation_tf_hat = lsim(W_hat,u_validation_tf,validation_tf.time);

% plot validation 
fig_validation_tf = figure('Name','validation_tf','WindowStyle','docked');
ax(1) = subplot(2,1,1);
hold all, grid on, box on;
set(gca,'DefaultLineLineWidth', 2,...
    'FontSize',15);
xlabel('time [s]');
ylabel('yaw rate [deg/s]');
plot(validation_tf.time,y_validation_tf,'o');
plot(validation_tf.time,y_validation_tf_hat,'o');
legend('measured','estimated');
ylim([-20 20]);

ax(end+1) = subplot(2,1,2);
hold all, grid on, box on;
set(gca,'DefaultLineLineWidth', 2,...
    'FontSize',15);
xlabel('time [s]');
ylabel('steering wheel [deg]');
plot(validation_tf.time,u_validation_tf,'o')

linkaxes(ax,'x'); clear ax;

%% validation double lane change (_dlc)

validation_experiment_dlc = load('./data/validation_experiment_dlc.mat');

u_validation_dlc        = validation_experiment_dlc.steering_wheel;
y_validation_dlc        = validation_experiment_dlc.yaw_rate;
y_validation_dlc_hat    = lsim(W_hat,u_validation_dlc,validation_experiment_dlc.time);

% plot validation 
fig_validation_dlc = figure('Name','validation_dlc','WindowStyle','docked');
ax(1) = subplot(2,1,1);
hold all, grid on, box on;
set(gca,'DefaultLineLineWidth', 2,...
    'FontSize',15);
xlabel('time [s]');
ylabel('yaw rate [deg/s]');
plot(validation_experiment_dlc.time,y_validation_dlc,'o');
plot(validation_experiment_dlc.time,y_validation_dlc_hat,'o');
legend('measured','estimated');

ax(end+1) = subplot(2,1,2);
hold all, grid on, box on;
set(gca,'DefaultLineLineWidth', 2,...
    'FontSize',15);
xlabel('time [s]');
ylabel('steering wheel [deg]');
plot(validation_experiment_dlc.time,u_validation_dlc,'o')

linkaxes(ax,'x'); clear ax;

