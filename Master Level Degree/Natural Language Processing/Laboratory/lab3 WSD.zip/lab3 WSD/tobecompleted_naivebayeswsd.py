'''
Created on May 13, 2014

@author: roberto

Trains and Tests a Naive Bayes classifier for recognizing "apple" as a fruit or as a company

Texts from: http://www.litfuel.net/plush/?postid=200
See the NLTK book: http://www.nltk.org/book/ch06.html

Ported to Python 3 on May 5, 2016

NB: this is a simplified classifier, as:
- It only classifies one word
- lemmas are used for both co-occurence and collocation
- The testing procedure does not apply the cross-validation methodology
'''

# imports...


def extract_context(list_of_lemmas, idx, context_limit):
    '''
    Extracts the left and right contexts (i.e., lists of lemmas) of the lemma in position 'idx'
    - list_of_lemmas: list containing a lemmatized text;
                      e.g.: ['jenn_barthole', 'apple', 'survey', 'are', 'apple', 'product', 'good', ...]
    - idx: the position of the target lemma inside the list of lemmas
    - context_limit: how many lemmas to consider, before and after idx;
    - returns:
        - the list of lemmas, with length context_limit, before idx;
          complete with '' if no enough lemmas are available before idx
        - the list of lemmas, with length context_limit, after idx;
          complete with '' if no enough lemmas are available after idx
    '''
    last = len(list_of_lemmas) - 1
    left_context = []
    right_context = []
    # Adds '' to fill left and right contexts, if they are close to the beginning or the end of the text
    l1 = idx - context_limit
    if l1 < 0:
        left_context += [''] * abs(l1)  # Notice the '+=' and '*' operators with lists: ['x']*3 --> ['x','x','x']
        l1 = idx - context_limit - l1
    left_context += list_of_lemmas[l1: idx]
    l2 = idx + context_limit
    if l2 > last:
        right_context += [''] * (l2 - last)
        l2 = idx + context_limit - (l2 - last)
    right_context = list_of_lemmas[idx + 1: l2 + 1] + right_context
    return left_context, right_context
    # E.g. ['jenn_barthole']   and   ['survey']

def get_best_co_occurring_lemmas(target_lemma, n, context_limit, texts):
    '''
    Returns the n most frequently co-occurring lemmas of the given target lemma
    - target_lemma: the lemma for which the co-occurring lemma must be found
    - n: how many co-occurring lemmas to retain
    - context_limit: how many lemmas to consider, before and after the target lemma
    - texts: the corpus; an hashtable where items are file names;
             e.g.: {'COMPANY': './data/apple-company-training.txt', 'FRUIT': './data/apple-fruit-training.txt'}
    - returns: a list of the n most co-occurring lemmas
    '''
    # E.g., ['crisp', 'http', 'ipad', 'iphone', 'juice', 'like', 'mac', 'make', 'making', 'pie', 'product', 'sauce']

    # Accumulate all the co-occurring lemmas within the specified context limit

    # Get the n most frequent co-occurring lemmas

def features(target_word, left_context_lemmas, right_context_lemmas, best_co_occurring_lemmas):
    '''
    Returns the feature set of a given target lemma: word, left collocations, right collocations, co_occurrence
    - target_word: the word to classify
    - left_context_lemmas: a list of lemmas, before the target word; e.g.: ['jenn_barthole']
    - right_context_lemmas: a list of lemmas, after the target word; e.g.: ['survey']
    - best_co_occurring_lemmas: the list of best co-occurring lemmas, for the target word;
      e.g.: e.g., ['crisp', 'http', 'ipad', 'iphone', 'juice', 'like', 'mac', 'make', 'making', 'pie', 'product', 'sauce']
    - returns: an hashtable {'word': ..., 'left_collocations': ..., 'right_collocations': ..., 'co_occurrence': ...};
    '''
    # e.g.: {'word': 'apples', 'left_collocations': ('jenn_barthole'), 'right_collocations': ('survey'),
    #        'co_occurrence': (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)}

    # Build co-occurrence vector, e.g. [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0]

def add_lemmas(text):
    '''
    Lemmatizes the text, using WordNet; returns (lemma, word) for each word in text
    NB: discards stopwords and tokens of 1 character
    - text: a string containing the text
    - returns: a list of pairs (lemma, word)
    '''
    # returns the pairs (lemma, word)

def main():
    # Define constants

    # Build vector of the best co-occurring lemmas, for all the meaning of the lemma to classify

    # Loop through each item, grab the text, tokenize it and create a training feature with it

    # Select training set and test set
    # Shuffling is needed so that train_set and test_set will contain samples from both the first and the second file

    # Train...

    # Test... Notice that each run will result in a different accuracy, as the train set is randomly chosen

    # Try to classify a new file and print the surrounding words of the classified lemma


if __name__ == '__main__':
    main()
