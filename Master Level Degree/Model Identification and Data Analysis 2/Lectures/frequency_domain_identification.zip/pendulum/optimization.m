clear
close all
clc

%% parameters 
Ts = 0.001;

%% sample frequency response
load .\data\sample_freq_resp.mat

fun = @(theta) cost_function(theta, sample_freq_resp, 2*pi*f_vect);
theta0 = [2 -1 1];

A = [];
b = [];
Aeq = [];
beq = [];
ub = [10 10 10];
lb = [-10 -10 -10];
nonlcon = [];

options = optimoptions('fmincon','Algorithm','Active-set',...
    'MaxFunctionEvaluations',10^7,...
    'MaxIterations',10^7,...
    'TolFun',1e-2,...
    'TolX', 1e-12,...
    'display','iter');

tic
theta_star = fmincon(fun, theta0, A, b, Aeq, beq, lb, ub, nonlcon, options);
toc


b1_star = theta_star(1)*1e-6;
a1_star = theta_star(2);
a2_star = theta_star(3);
W_hat = @(x) (b1_star)/(x^2+a1_star*x+a2_star);

% save('.\data\optimization_result.mat','b1_star','a1_star','a2_star');

%% plot transfer function
close all
freq_vect = linspace(f_vect(1), f_vect(end), 100);
omega_vect = 2*pi*freq_vect;
 
h_hat = arrayfun(W_hat, exp(1i*omega_vect*Ts));
mag_db_hat = mag2db(abs(h_hat));
ph_hat = angle(h_hat)*180/pi;

figure
ax_freq(1) = subplot(2,1,1); hold all, grid on, box on; ylabel('mag [dB]'); xlabel('f [Hz]'); set(gca, 'XScale','Log');
scatter(f_vect, mag2db(abs(sample_freq_resp)));
plot(freq_vect, mag_db_hat);
ax_freq(2) = subplot(2,1,2); hold all, grid on, box on; ylabel('ph [deg]'); xlabel('f [Hz]'); set(gca, 'XScale','Log');
scatter(f_vect, angle(sample_freq_resp)*180/pi);
plot(freq_vect, ph_hat);
