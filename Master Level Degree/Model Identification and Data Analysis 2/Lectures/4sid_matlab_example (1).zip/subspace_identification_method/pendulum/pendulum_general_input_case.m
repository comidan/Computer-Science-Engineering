clear
close all
clc

%% pendulum Torque2Position transfer function estimation - general input

%% system parameters 
m    = 1;               % [kg]      mass
l    = 0.5;             % [m]       rod length
g    = 9.81;            % [m/s^2]   gravitational acceleration 
c    = 1;               % [N*m*s]   damping coefficient
Ts   = 0.01;            % [s]       sampling time (100 Hz)
N    = 10000;           % []        number of measurement
Tf   = Ts*(N-1);        % [s]       simulation duration
time = 0:Ts:Tf;         % [s]       time vector

noise_free = false;     % true = mesurements without noise - false = measurements with noise

%% input definition
% we choose to use a filtered white gaussian noise as input 

u_wgn = wgn(1,N,20);    % definition of a white gaussian noise

% white gaussian noise filtering
s          = tf('s');
LP_freq    = 5;                                 % LP filter bandwith
LP_filter  = 1/(s/(2*pi*LP_freq)+1);            % first order LP filter
u_wgn_filt = lsim(LP_filter, u_wgn, time);      % white gaussian noise filtering

%% simulation 
u_experiment = u_wgn_filt;
u_sim        = timeseries(u_experiment,time);

sim('pendulum_sim');                                                        
y_experiment      = y_sim;                                                  
y_experiment_deg  = y_experiment*180/pi;                                 

% experiment plot
fig_inpulse_response = figure('Name','impulse_response');                   
ax(1) = subplot(2,1,1);                                                     
hold all, grid on, box on;                                                  
set(gca,'FontSize',15,'DefaultLineLineWidth',2);                                                
xlabel('time [s]');                                                         
ylabel('position [deg]');                                                   
plot(time,y_experiment_deg,'o');                                            
    
ax(2) = subplot(2,1,2);                                                     
hold all, grid on, box on;                                                  
set(gca,'FontSize',15,'DefaultLineLineWidth',2);                           
xlabel('time [s]');                                                         
ylabel('\tau [Nm]');                                                        
plot(time, u_experiment);                                                   

linkaxes(ax,'x'); clear ax; % graphical cmd (linkaxes)

%% choice of system order
n = 2;

%% identification 
data     = iddata(y_experiment,u_experiment,Ts);                            % input for n4sid function 
n4sidopt = n4sidOptions('EnforceStability',true);                           % option of n4sid 
sys      = n4sid(data, n, n4sidopt);                                        % function that use the 4SID method

F = sys.A;
G = sys.B;
H = sys.C;
D = sys.D;

W_hat  = tf(ss(F,G,H,D,Ts));

%% validation step
step_time      = 1;
step_amplitude = 2;

u_validation        = step_amplitude*(time >= step_time);                   % step input definition
u_sim               = timeseries(u_validation,time);                        % simulation input definition
sim('pendulum_sim');
y_validation        = y_sim;
y_validation_hat    = lsim(W_hat,u_validation,time);

% plot validation 
fig_validation = figure('Name','validation','WindowStyle','docked');
ax(1) = subplot(2,1,1);
hold all, grid on, box on;
set(gca,'DefaultLineLineWidth', 2,...
    'FontSize',15);
xlabel('time [s]');                                                         % graphical cmd
ylabel('position [deg]');
plot(time,y_validation*180/pi,'o')
plot(time,y_validation_hat*180/pi,'o');
legend('measured','estimated');

ax(end+1) = subplot(2,1,2);
hold all, grid on, box on;
set(gca,'DefaultLineLineWidth', 2,...
    'FontSize',15);
xlabel('time [s]');                                                         
ylabel('\tau [Nm]');
plot(time,u_validation,'o')

linkaxes(ax,'x');
xlim([0,5])
