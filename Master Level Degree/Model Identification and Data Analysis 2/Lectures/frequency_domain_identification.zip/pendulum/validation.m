clear
close all
clc


%% system parameters
m    = 1;         % [kg]      mass
l    = 0.5;       % [m]       rod length
g    = 9.81;      % [m/s^2]   gravitational acceleration
c    = 1;         % [N*m*s]   damping coefficient
Ts   = 0.001;     % [s]       sampling time (100 Hz)

noise_gain = 1;   %[ ] noise gain


%% optimization result 
load .\data\optimization_result.mat
load .\data\sample_freq_resp.mat

W_hat_fun = @(x) (b1_star)/(x^2+a1_star*x+a2_star);
freq_vect = linspace(f_vect(1), f_vect(end), 100);
omega_vect = 2*pi*freq_vect;
 
h_hat = arrayfun(W_hat_fun, exp(1i*omega_vect*Ts));
mag_db_hat = mag2db(abs(h_hat));
ph_hat = angle(h_hat)*180/pi;

figure
ax_freq(1) = subplot(2,1,1); hold all, grid on, box on; ylabel('mag [dB]'); xlabel('f [Hz]'); set(gca, 'XScale','Log');
scatter(f_vect, mag2db(abs(sample_freq_resp)));
plot(freq_vect, mag_db_hat);
ax_freq(2) = subplot(2,1,2); hold all, grid on, box on; ylabel('ph [deg]'); xlabel('f [Hz]'); set(gca, 'XScale','Log');
scatter(f_vect, angle(sample_freq_resp)*180/pi);
plot(freq_vect, ph_hat);


%% validation

z = tf('z');
W_hat = b1_star/(z^2 + a1_star*z+a2_star);
W_hat.Ts = Ts;

Tf = 5;
time = 0:Ts:Tf;


% step input definition
step_time      = 1;
step_amplitude = 2;

u_validation        = step_amplitude*(time >= step_time);                   % step input definition
u_sim               = timeseries(u_validation,time);                        % simulation input definition
sim('pendulum_sim');
y_validation        = y_sim.Data;
y_validation_hat    = lsim(W_hat,u_validation,time);                        % lsim simulate a linear system described by a transfer function


% plot validation 
fig_validation = figure('Name','validation');
subplot(2,1,1)
hold all, grid on, box on;
set(gca,'DefaultLineLineWidth', 2,...
    'FontSize',15);
xlabel('time [s]');                                                         % graphical cmd
ylabel('position [deg]');
plot(time,y_validation*180/pi,'o')
plot(time,y_validation_hat*180/pi,'o');
legend('measured','estimated');

subplot(2,1,2)
hold all, grid on, box on;
set(gca,'DefaultLineLineWidth', 2,...
    'FontSize',15);
xlabel('time [s]');                                                         
ylabel('\tau [Nm]');
plot(time,u_validation,'o')
